# tsvio
R package for reading (subsets of) tsv files

To install this package into R:
```
> install.packages("devtools")
> devtools::install_github("bmbroom/tsvio", ref="stable")
```

You can also choose to install from the master branch.

The installed package will be called tsvio:
```
> library (NGCHM)
```
